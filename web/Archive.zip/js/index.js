$(document).ready(function(){
  $('.flexslider').flexslider({
    controlNav: false
  });  
});